package com.example.postman;

public interface JokeLoader {
    void onPostExecute();
}
